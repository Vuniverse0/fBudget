#include "Budget.hpp"

#include <cstdio>
#include <filesystem>
#include <cstring>
#include <iostream>

#include <Fl/Fl_Input_.H>
#include <Fl/Fl_Choice.H>
#include <Fl/Fl_Output.H>


Budget *Budget::current{nullptr};

Budget::Budget(std::int16_t a_year, std::int8_t a_month)
    :year{a_year}
    ,month{a_month}
{
    load();
    if(output_balance){
        update();
    }
}

Budget::~Budget()
{ save(); }

void Budget::addIncome(Fl_Widget *, void *)
{
    if(std::strcmp(income_source.numb->value(), "") == 0)
        return;

    auto tmp = strtof(income_source.numb->value(), nullptr);

    current->incomes.push_back({tmp, MyTime().day});

    auto &ref = current->incomes[current->spends.size()-1];

    if(std::strcmp(income_source.name->value(), "") == 0)
        std::strcpy(ref.name, "Пусте");
    else
        std::strncpy(ref.name, income_source.name->value(),
                     std::strlen(income_source.name->value()) + 1 < PAYMENT_NAME_SIZE ?
                     std::strlen(income_source.name->value()) + 1 :
                     (ref.name[PAYMENT_NAME_SIZE - 1] = '\0',PAYMENT_NAME_SIZE - 1));

    if(std::strcmp(income_source.note->value(), "") == 0)
        std::strcpy(ref.note, "Пусте");
    else
        std::strncpy(ref.note, income_source.note->value(),
                     std::strlen(income_source.note->value()) + 1 < PAYMENT_NOTE_SIZE ?
                     std::strlen(income_source.note->value()) + 1 :
                     (ref.note[PAYMENT_NOTE_SIZE - 1] = '\0',PAYMENT_NOTE_SIZE - 1));

    current->income += tmp;
    current->balance += tmp;

    current->updateIncome();
    current->updateOutput();

    income_source.name->clear_output();
    income_source.note->clear_output();
    income_source.numb->clear_output();
}

void Budget::addSpend(Fl_Widget *, void *)
{
    if(std::strcmp(spend_source.numb->value(), "") == 0)
        return;

    auto tmp = strtof(spend_source.numb->value(), nullptr);

    current->spends.push_back({tmp, MyTime().day});

    auto &ref = current->spends[current->spends.size()-1];

    if(std::strcmp(spend_source.name->value(), "") == 0)
        std::strcpy(ref.name, "Пусте");
    else
        std::strncpy(ref.name, spend_source.name->value(),
                     std::strlen(spend_source.name->value()) + 1 < PAYMENT_NAME_SIZE ?
                     std::strlen(spend_source.name->value()) + 1 :
                     (ref.name[PAYMENT_NAME_SIZE - 1] = '\0', PAYMENT_NAME_SIZE - 1));

    if(std::strcmp(spend_source.note->value(), "") == 0)
        std::strcpy(ref.note, "Пусте");
    else
        std::strncpy(ref.note, spend_source.note->value(),
                     std::strlen(spend_source.note->value()) + 1 < PAYMENT_NOTE_SIZE ?
                     std::strlen(spend_source.note->value()) + 1 :
                     (ref.note[PAYMENT_NOTE_SIZE - 1] = '\0',PAYMENT_NOTE_SIZE - 1));

    current->spend += tmp;
    current->balance -= tmp;

    current->updateSpend();
    current->updateOutput();

    spend_source.name->clear_output();
    spend_source.note->clear_output();
    spend_source.numb->clear_output();
}

void Budget::setIncome(Fl_Choice *choice, Fl_Output *output, Fl_Input_ *name, Fl_Input_ *note, Fl_Input_ *numb)
{ income_source = {choice, output, name, note, numb}; }

void Budget::setSpend(Fl_Choice *choice, Fl_Output *output, Fl_Input_ *name, Fl_Input_ *note, Fl_Input_ *numb)
{ spend_source = {choice, output, name, note, numb}; }

void Budget::save()
{
    FILE *file = std::fopen((std::to_string(month) + "-" + std::to_string(year) + ".budget").c_str(), "wb");
    std::fwrite(buff_float, 1, sizeof(buff_float), file);
    std::size_t buff_sizes[2]{incomes.size(), spends.size()};
    std::fwrite(buff_sizes, 1, sizeof(buff_sizes), file);
    std::fwrite(incomes.data(), 1, buff_sizes[0] * sizeof(Income), file);
    std::fwrite(spends.data(), 1, buff_sizes[1] * sizeof(Spend), file);
}

void Budget::load()
{
    FILE *file = std::fopen((std::to_string(month) + "-" + std::to_string(year) + ".budget").c_str(), "rb");
    if(!file)
        return;
    std::fread(buff_float, 1, sizeof(buff_float), file);
    std::size_t buff_sizes[2]{};
    std::fread(buff_sizes, 1, sizeof(buff_sizes), file);
    incomes.resize(buff_sizes[0]), spends.resize(buff_sizes[1]);
    std::fread(incomes.data(), 1, buff_sizes[0] * sizeof(Income), file);
    std::fread(spends.data(), 1, buff_sizes[1] * sizeof(Spend), file);
}

void Budget::create(std::int16_t a_year, std::int8_t a_month)
{
    delete current;
    current = new Budget(a_year, a_month);
}

void Budget::createCb(Fl_Widget *, void *)
{
    if(year_source == nullptr || month_source == nullptr && current == nullptr)
        create(MyTime().year, MyTime().month);
    else{
        create(year_source->value(), month_source->value());
        std::cerr << MyTime().year + year_source->value() - 10 << "    ";
        std::cerr << MyTime::months[month_source->value()] << std::endl;
    }
}

void Budget::setCalendar(Fl_Choice *a_year, Fl_Choice *a_month)
{ year_source = a_year, month_source = a_month; }

void Budget::deleteIncomeCb(Fl_Widget *, void *)
{
    auto it = current->incomes.begin() + income_source.choice->value();
    current->income -= it->amount;
    current->balance -= it->amount;
    current->incomes.erase(it);
    current->updateIncome();
}

void Budget::deleteSpendCb(Fl_Widget *, void *)
{
    auto it = current->spends.begin() + spend_source.choice->value();
    current->spend -= it->amount;
    current->balance += it->amount;
    current->spends.erase(it);
    current->updateSpend();
}

void Budget::updateSpend()
{
    std::stringstream ss;
    int i = 0;
    for(auto &item : spends)
        ss << ++i << ". " << item.name << ": " << item.amount << "\n                       "
           << item.note << "      Дата: " << std::to_string(item.day) << " " << MyTime::months[current->month] << "\n";
    spend_source.output->value(ss.str().c_str());
    i=0, spend_source.choice->clear();
    spend_source.choice->add(" ");
    spend_source.choice->value(0);
    spend_source.choice->clear();
    for(auto &item : spends)
        spend_source.choice->add((std::to_string(++i) + ". "+ item.name).c_str());
    spend_source.choice->value(0);
}

void Budget::updateIncome()
{
    std::stringstream ss;
    int i = 0;
    for(auto &item : incomes)
        ss<<++i<<". "<<item.name<<": "<<item.amount<<"\n                       "
          <<item.note<<"      Число: "<<std::to_string(item.day)<<"\n";
    income_source.output->value(ss.str().c_str());
    i=0, income_source.choice->clear();
    income_source.choice->add(" ");
    income_source.choice->value(0);
    income_source.choice->clear();
    for(auto &item : incomes)
        income_source.choice->add((std::to_string(++i) + ". "+ item.name).c_str());
    income_source.choice->value(0);
}

void Budget::setOutput(Fl_Output *a_output_balance, Fl_Output *a_output_spend, Fl_Output *a_output_income)
{
    output_balance = a_output_balance;
    output_spend = a_output_spend;
    output_income = a_output_income;
}

void Budget::updateOutput() const
{
    output_balance->value(("Баланс: " + std::to_string(balance)).c_str());
    output_spend->value(("Витрати: " + std::to_string(spend)).c_str());
    output_income->value(("Прибуток: " + std::to_string(income)).c_str());
}

void Budget::update()
{
    updateIncome();
    updateSpend();
    updateOutput();
}
