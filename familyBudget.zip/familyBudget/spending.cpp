#include "pages.hpp"
#include "Budget.hpp"

#include <FL/Fl_Widget.H>
#include <FL/Fl_Group.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Box.H>
#include <Fl/Fl_Choice.H>
#include <FL/Fl_Int_Input.H>
#include <FL/Fl_Float_Input.H>
#include <FL/Fl_Input.H>
//include <FL/Fl_Lable.H>
#include <FL/Fl_Multiline_Output.H>
#include <iostream>
#include <cstring>


void spends_page()
{
    auto *g = new Fl_Group(0, 0, width, height);

    std::size_t buttons_number = 6,
            local_height = 30,
            button_width = (width - offset * (buttons_number + 1)) / buttons_number,
            button_height = (local_height - offset),
            i = 0,
            relative_size = 2;
    auto *income_name = new Fl_Input(offset, offset + button_height,
                                     button_width * relative_size, button_height, "");
    new Fl_Box(offset, offset, button_width * relative_size, button_height, "Ім'я");
    i += relative_size;
    relative_size = 2;
    auto *income_note = new Fl_Input(button_width * i + offset * i + offset, offset + button_height,
                                     button_width * relative_size, button_height, "");
    new Fl_Box(button_width * i + offset * i + offset, offset, button_width * relative_size, button_height, "Замітка");

    i += relative_size;
    relative_size = 1;
    auto *income_int = new Fl_Float_Input(button_width * i + offset * i + offset, offset + button_height,
                                          button_width * relative_size, button_height, "");
    new Fl_Box(button_width * i + offset * i + offset, offset, button_width * relative_size, button_height, "Сумма");

    i += relative_size;
    auto *add_income = new Fl_Button(button_width * i + offset * i + offset, offset + button_height,
                                     button_width * relative_size, button_height, "+");
    new Fl_Box(button_width * i + offset * i + offset, offset, button_width * relative_size, button_height, "Додати");
    add_income->callback(Budget::addSpend);

    auto *output = new Fl_Multiline_Output(offset, button_height*2 + offset * 2,
                                           width - offset * 2, height - offset * 4 - button_height * 2 - 100, "");


    i = 0;
    button_height = 100;
    buttons_number = 3, button_width = (width - offset * (buttons_number + 1)) / buttons_number;
    auto *exit = new Fl_Button(button_width * i + offset * i + offset, height - offset - button_height,
                               button_width, button_height - offset, "Назад");
    exit->callback(toMainMenu);
    i++;
    auto *choice_remove = new Fl_Choice(button_width * i + offset * i + offset, height - offset - button_height,
                                        button_width, button_height - offset, "");
    i++;
    auto *remove = new Fl_Button(button_width * i + offset * i + offset, height - offset - button_height,
                                 button_width, button_height - offset, "Видалити");
    remove->callback(Budget::deleteSpendCb);
    Budget::setSpend(choice_remove, output, income_name, income_note, income_int);
    Budget::current->update();
    g->end();
}