#ifndef MINGWINSTALLER_PAGES_HPP
#define MINGWINSTALLER_PAGES_HPP

#include <string>

#include "Manager.hpp"

class Fl_Widget;

constexpr std::size_t width = 650 + 300;
constexpr std::size_t height = 600 + 10;
constexpr std::size_t png_size = 300;
constexpr std::size_t offset = 10;

void nextCb(Fl_Widget*, void*);
void backCb(Fl_Widget*, void*);
void exitCb(Fl_Widget*, void*);
void toMainMenu(Fl_Widget*, void*);
void setPage(std::size_t page);

template<std::size_t Page>
static void callback(Fl_Widget*, void*)
{ setPage(Page); }

void showError(const char* error);

#endif //MINGWINSTALLER_PAGES_HPP
