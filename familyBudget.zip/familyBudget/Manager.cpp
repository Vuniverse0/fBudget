#include "Manager.hpp"

#include <cassert>
#include <stdexcept>

#include "pages.hpp"
#include "line_as_string_literal.hpp"
#include "Budget.hpp"


Manager Manager::manager{};

void Manager::createPages()
{

    g_win = new Fl_Window(400, 300, width, height, "Сімейний бюджет");
    g_wiz = new Fl_Wizard(0, 0, width, height);

#ifdef INCON_IMAGE
#ifndef ICON_DATA
#error "Icon data not defined"
#endif
#ifndef ICON_SIZE
#error "Icon size not defined"
#endif
    g_win->icon(new Fl_PNG_Image("", ICON_DATA, static_cast<int>(ICON_SIZE)));
#endif

    for(auto &item : pages)
        item();

    g_wiz->end();
    g_win->end();
    g_win->show();
}

void Manager::prevPage()
{
    assert(g_wiz);
    if(current_page == 0)
        throw std::out_of_range("Manager: prevPage(): " __FILE__ ": " LINE);
    --current_page;
    if(g_wiz)
        g_wiz->prev();
}

void Manager::nextPage()
{
    assert(g_wiz);
    ++current_page;
    if(current_page >= pages.size())
        throw std::out_of_range("Manager: nextPage(): " __FILE__ ": " LINE);
    if(g_wiz)
        g_wiz->next();
}

void Manager::close()
{
    assert(g_win);
    delete Budget::current;
    if(g_win)
        g_win->hide();
};

void Manager::addPage(const std::function<void()>& page)
{
    assert(g_win == nullptr && g_wiz == nullptr);
    pages.push_back(page);
}

void Manager::setPage(std::size_t n)
{
    while(current_page != n)
        if(current_page > n)
            prevPage();
        else
            nextPage();
}
