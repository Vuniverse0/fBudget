#include "Manager.hpp"
#include "Budget.hpp"

#include <FL/Fl.H>


void main_page();

void incomes_page();

void spends_page();

void showError(const char* error)
{ printf("%s", error); }

int main(int argc, char **argv)  try
{
    Fl::scheme("gtk+");

    Manager::manager.addPages(main_page, incomes_page, spends_page);

    Manager::manager.createPages();

    auto result = Fl::run();
    delete Budget::current;
    return result;
}catch(std::exception& error){
    showError(error.what());
}
