#include "pages.hpp"
#include "Budget.hpp"

#include <FL/Fl_Group.H>
#include <FL/Fl_Button.H>
#include <Fl/Fl_Choice.H>
#include <FL/Fl_Output.H>
#include <Fl/Fl_Help_View.H>


void main_page()
{
    Budget::createCb(nullptr, nullptr);

    auto *g = new Fl_Group(0, 0, width, height);

    std::size_t buttons_number = 2,
    local_height = 200,
    button_width = (width - offset * (buttons_number + 1)) / buttons_number,
    button_height = (local_height - offset * buttons_number) / buttons_number,
    i = 0;

    auto *incomes = new Fl_Button(button_width * i + offset * i + offset, offset,
                                  button_width, button_height, "Доходи");
    incomes->callback(callback<1>);
    ++i;

    auto *spending = new Fl_Button(button_width * i + offset * i + offset, offset,
                                    button_width, button_height, "Витрати");
    spending->callback(callback<2>);

    i=0;

    auto *choice_month = new Fl_Choice(button_width * i + offset * i + offset, offset*2 + button_height,
                                       button_width, button_height, "");

    for(auto &item : MyTime::months)
        choice_month->add(item);

    choice_month->value(MyTime().month);
    choice_month->textsize(20);
    choice_month->callback(Budget::createCb);

    ++i;

    auto *choice_year = new Fl_Choice(button_width * i + offset * i + offset, offset*2 + button_height,
                                      button_width, button_height, "");

    for(auto j = MyTime().year - 10, end = j + 20; j != end ; ++j)
        choice_year->add(std::to_string(j).c_str());

    choice_year->value(10);
    choice_year->textsize(20);
    choice_year->callback(Budget::createCb);

    Budget::setCalendar(choice_year, choice_month);

    auto *income = new Fl_Output(offset, offset * 4 + button_height * 2, button_width, button_height, "");
    auto *spend = new Fl_Output(offset*2 + button_width, offset * 4 + button_height * 2, button_width, button_height, "");
    auto *balance = new Fl_Output(offset, offset * 5 + button_height * 3, width - offset * 2, button_height, "");

    Budget::setOutput(balance, spend, income);

    auto *text = new Fl_Help_View(offset + button_width/2, offset * 6 + button_height * 4,
                                  width - button_width - offset * 2, button_height);
    text->value("<p><a href=\"https://savelife.in.ua/\">Допомога ЗСУ</a></p>");
    text->textsize(30);
    i = 0;
    buttons_number = 1, button_width = (width - offset * (buttons_number + 1)) / buttons_number;
    auto *exit = new Fl_Button(button_width * i + offset * i + offset, height - offset - button_height,
                               button_width, button_height, "Вийти");
    exit->callback(exitCb);

    g->end();
}
