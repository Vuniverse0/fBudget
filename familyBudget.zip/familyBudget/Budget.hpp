#ifndef FAMILYBUDGET_BUDGET_HPP
#define FAMILYBUDGET_BUDGET_HPP

#include <vector>
#include <string>
#include <cmath>
#include <array>

#define PAYMENT_NAME_SIZE 60
#define PAYMENT_NOTE_SIZE 60

class Fl_Widget;
class Fl_Input_;
class Fl_Output;
class Fl_Choice;

struct Payment{
    std::float_t amount;
    std::int8_t day;
    char name[PAYMENT_NAME_SIZE];
    char note[PAYMENT_NOTE_SIZE];
};

struct Spend : Payment{};
struct Income : Payment{};

struct Budget final {
    static Budget* current;
    static void create(std::int16_t a_year, std::int8_t a_month);

    static void setIncome(Fl_Choice *choice, Fl_Output *output, Fl_Input_ *name, Fl_Input_ *note, Fl_Input_ *numb);
    static void setSpend(Fl_Choice *choice, Fl_Output *output, Fl_Input_ *name, Fl_Input_ *note, Fl_Input_ *numb);
    static void setOutput(Fl_Output *a_output_balance, Fl_Output *a_output_spend, Fl_Output *a_output_income);
    static void setCalendar(Fl_Choice *a_year, Fl_Choice *a_month);

    static void addIncome(Fl_Widget*, void*);
    static void deleteIncomeCb(Fl_Widget*, void*);
    static void addSpend(Fl_Widget*, void*);
    static void deleteSpendCb(Fl_Widget*, void*);
    static void createCb(Fl_Widget*, void*);
    void save();
    void load();
    void update();

    ~Budget();

private:
    Budget(std::int16_t a_year, std::int8_t a_month);

    void updateSpend();
    void updateIncome();
    void updateOutput() const;

    std::int8_t month{0};
    std::int16_t year{0};
    inline static Fl_Choice *month_source{nullptr}, *year_source{nullptr};
    inline static Fl_Output *output_balance{nullptr}, *output_spend{nullptr}, *output_income{nullptr};
    inline static struct{
        Fl_Choice *choice;
        Fl_Output *output;
        Fl_Input_ *name, *note, *numb;
    } income_source{nullptr, nullptr, nullptr, nullptr}, spend_source{nullptr, nullptr, nullptr, nullptr};
    std::vector<Spend> spends{};
    std::vector<Income> incomes{};
    union {
        std::float_t buff_float[3]{0.f, 0.f, 0.f};
        struct {
            std::float_t balance, income, spend;
        };
    };

};

struct MyTime{
    explicit inline MyTime(tm time)
            :day{static_cast<int8_t>(time.tm_mday)}
            ,month{static_cast<int8_t>(time.tm_mon)}
            ,year{static_cast<int16_t>(1900 + time.tm_year)}
    {}
    inline MyTime() : MyTime(currentDateTime()) {}
    [[nodiscard]] const char* getMonth() const
    { return months[month]; }

    inline static std::array<const char*, 12> months
            {"Січень", "Лютий", "Березень",
             "Квітень", "Травень", "Червень",
             "Липень", "Серпень", "Вересень",
             "Жовтень", "Листопад", "Грудень"};

    std::int8_t day, month;
    std::int16_t year;

private:
    static tm currentDateTime()
    {
        time_t now = time(nullptr);
        tm  tstruct{};
        tstruct = *localtime(&now);
        return tstruct;
    }
};

#endif //FAMILYBUDGET_BUDGET_HPP
