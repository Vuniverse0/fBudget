#include "Manager.hpp"


class Fl_Widget;

void backCb(Fl_Widget*, void*)
{ Manager::manager.prevPage(); }

void nextCb(Fl_Widget*, void*)
{ Manager::manager.nextPage(); }

void exitCb(Fl_Widget*, void*)
{ Manager::manager.close(); }

void setPage(std::size_t page)
{ Manager::manager.setPage(page); }

void toMainMenu(Fl_Widget*, void*)
{ setPage(0); }
