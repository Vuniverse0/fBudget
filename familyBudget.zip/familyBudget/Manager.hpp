#ifndef FAMILYBUDGET_MANAGER_HPP
#define FAMILYBUDGET_MANAGER_HPP

#include <vector>
#include <functional>
#include <cstdint>

#include <FL/Fl_Window.H>
#include <FL/Fl_Wizard.H>


struct Manager final {
    static Manager manager;

    void createPages();
    void addPage(const std::function<void()>& page);

    template<typename ...Args>//not enable if because it needs for SFINAE
    void addPages(Args&&... args)
    {
        static_assert
        ((
            (std::is_convertible_v<Args, std::function<void()>> or std::is_constructible_v<std::function<void()>,
            Args>) and ...
        ));
        pages.reserve(pages.size() + sizeof...(args));
        (addPage(std::forward<Args>(args)), ...);
    }

    void setPage(std::size_t n);
    void prevPage();
    void nextPage();
    void close();

private:
    Manager() = default;

    std::vector<std::function<void()>> pages{};

    std::size_t current_page{0};

    Fl_Window *g_win{nullptr};
    Fl_Wizard *g_wiz{nullptr};
};

#endif //FAMILYBUDGET_MANAGER_HPP
