#include <SFML/Graphics/CircleShape.hpp>
#include <SFML/Graphics/Sprite.hpp>

#include "Interface.hpp"
#include "Board.h"

#include <cstdio>
#include <SFML/Window/Event.hpp>

void menu();
namespace {
    const unsigned WINDOW_WIDTH = 1152;
    const unsigned WINDOW_HEIGHT = 864;
    int NUM_COLUMNS = 19,
    NUM_ROWS = 19;
#define BOARD_WIDTH static_cast<int>((NUM_COLUMNS) * 40)
#define BOARD_HEIGHT static_cast<int>((NUM_ROWS) * 40)
#define X_MARGIN static_cast<int>((WINDOW_WIDTH - BOARD_WIDTH) / 2)
#define Y_MARGIN static_cast<int>((WINDOW_HEIGHT - BOARD_HEIGHT) / 2)
#define SQUARE_SIZE static_cast<int>(BOARD_WIDTH / NUM_COLUMNS)
#define DISC_RADIUS static_cast<int>(SQUARE_SIZE / 2 * 0.75)
}

void Interface::create_board()
{
    auto style = sf::Style::Default;
    sf::ContextSettings m_settings;
    m_settings.antialiasingLevel = 8;
    std::string m_window_title = "Го";
    get_game_window().create({WINDOW_WIDTH, WINDOW_HEIGHT}, m_window_title, style, m_settings);
    m_desk.create(WINDOW_WIDTH, WINDOW_HEIGHT);
    get_game_window().setFramerateLimit(30);
    get_game_window().clear(sf::Color::White);
    m_desk.clear(sf::Color::White);

    m_screen_rect.setSize(sf::Vector2f(BOARD_WIDTH, BOARD_HEIGHT));
    m_screen_rect.setFillColor(sf::Color::White);
    m_screen_rect.setOrigin(-X_MARGIN, -Y_MARGIN);
    m_screen_rect.setPosition(0, 0);
    m_desk.draw(m_screen_rect);

    m_board_rect.setSize(sf::Vector2f((NUM_COLUMNS - 1) * SQUARE_SIZE, (NUM_ROWS - 1) * SQUARE_SIZE));
    m_board_rect.setFillColor(sf::Color(255, 150, 50));
    m_board_rect.setOrigin(-X_MARGIN, -Y_MARGIN);
    m_board_rect.setPosition(0, 0);
    m_desk.draw(m_board_rect);

    double black_line_thickness = 1.25;

    sf::RectangleShape black_line_rect_horiz;
    black_line_rect_horiz.setSize(sf::Vector2f(BOARD_WIDTH - SQUARE_SIZE, 1));
    black_line_rect_horiz.setFillColor(sf::Color::Black);
    black_line_rect_horiz.setOutlineColor(sf::Color::Black);
    black_line_rect_horiz.setOutlineThickness(black_line_thickness);
    black_line_rect_horiz.setOrigin(0, 0);

    sf::RectangleShape black_line_rect_vert;
    black_line_rect_vert.setSize(sf::Vector2f(1, BOARD_HEIGHT - SQUARE_SIZE));
    black_line_rect_vert.setFillColor(sf::Color::Black);
    black_line_rect_vert.setOutlineColor(sf::Color::Black);
    black_line_rect_vert.setOutlineThickness(black_line_thickness);
    black_line_rect_vert.setOrigin(0, 0);

    for (int i = 0; i < NUM_COLUMNS; i++) {
        black_line_rect_horiz.setPosition(X_MARGIN, Y_MARGIN + i * SQUARE_SIZE);
        m_desk.draw(black_line_rect_horiz);

        black_line_rect_vert.setPosition(X_MARGIN + i * SQUARE_SIZE, Y_MARGIN);
        m_desk.draw(black_line_rect_vert);
    }
}

sf::RenderWindow &Interface::get_game_window()
{
    return *m_window;
}

void Interface::draw()
{
    get_game_window().clear(sf::Color::White);
    get_game_window().draw(sf::Sprite(m_desk.getTexture()));

    sf::CircleShape black_circle;
    black_circle.setRadius(DISC_RADIUS);
    black_circle.setFillColor(sf::Color::Black);
    black_circle.setOutlineThickness(2.35);
    black_circle.setOutlineColor(sf::Color::Black);

    sf::CircleShape white_circle;
    white_circle.setRadius(DISC_RADIUS);
    white_circle.setFillColor(sf::Color::White);
    white_circle.setOutlineThickness(2.35);
    white_circle.setOutlineColor(sf::Color::Black);

    for (int i = 0; i < NUM_COLUMNS; i++) {
        for (int j = 0; j < NUM_ROWS; j++) {
            if (m_board[NUM_COLUMNS * i + j] == Player::White) {
                black_circle.setPosition(X_MARGIN + (j - 0.5) * SQUARE_SIZE + (SQUARE_SIZE - 2 * DISC_RADIUS) / 2,
                                         Y_MARGIN + (i - 0.5) * SQUARE_SIZE + (SQUARE_SIZE - 2 * DISC_RADIUS) / 2);
                get_game_window().draw(black_circle);
            } else if (m_board[NUM_COLUMNS * i + j] == Player::Black) {
                white_circle.setPosition(X_MARGIN + (j - 0.5) * SQUARE_SIZE + (SQUARE_SIZE - 2 * DISC_RADIUS) / 2,
                                         Y_MARGIN + (i - 0.5) * SQUARE_SIZE + (SQUARE_SIZE - 2 * DISC_RADIUS) / 2);
                get_game_window().draw(white_circle);
            }
        }
    }
    get_game_window().display();
}

Interface::Interface(std::size_t size, sf::RenderWindow &window)
    :m_board{(size) * (size), Player::None}
    ,m_window{&window}
{
    NUM_COLUMNS = NUM_ROWS = static_cast<int>(size);
    create_board();
}

void Interface::place(std::size_t x, std::size_t y, Player player)
{
    //place(static_cast<std::size_t>(board->get_vertex(cords.x, cords.y)), player);
    place(x + NUM_COLUMNS * y, player);
}

void Interface::save(const std::string& nameFile)
{
    FILE *file = std::fopen(nameFile.c_str(), "wb");
    auto size = m_board.size();
    std::fwrite(&size, 1, sizeof(size), file);
    std::fwrite(m_board.data(), sizeof(Player), m_board.size(), file);
}

Interface::Interface(const std::string& nameFile)
{
    FILE *file = std::fopen(nameFile.c_str(), "rb");
    auto size = m_board.size();
    std::fread(&size, 1, sizeof(size), file);
    m_board.resize(size);
    std::fread(m_board.data(), sizeof(Player), size, file);
    NUM_COLUMNS = NUM_ROWS = static_cast<int>(size);
    create_board();
}

Interface::Input Interface::get_input()
{
    int x_coord;
    int y_coord;
    int input_move;
    sf::Event player_event{};
    while (get_game_window().pollEvent(player_event)) {
        if (player_event.type == sf::Event::Closed) {
            menu();
        } else if (player_event.type == sf::Event::MouseButtonPressed) {
            if (player_event.mouseButton.button == sf::Mouse::Left) {
                //std::cout << "left click" << std::endl;
                sf::Vector2f cursor_pos(player_event.mouseButton.x, player_event.mouseButton.y);
                x_coord = (cursor_pos.x - X_MARGIN + SQUARE_SIZE / 2) / SQUARE_SIZE;
                y_coord = (cursor_pos.y - Y_MARGIN + SQUARE_SIZE / 2) / SQUARE_SIZE;
                sf::FloatRect containing_rect(m_board_rect.getLocalBounds().left + X_MARGIN - SQUARE_SIZE / 2,
                                              m_board_rect.getLocalBounds().top + Y_MARGIN - SQUARE_SIZE / 2,
                                              m_board_rect.getLocalBounds().width + SQUARE_SIZE,
                                              m_board_rect.getLocalBounds().height + SQUARE_SIZE);
                if (containing_rect.contains(cursor_pos)) {
                    int input_x_coord = x_coord;
                    int input_y_coord = y_coord;
                    //input_move = board->get_vertex(x_coord, y_coord);
                    //input_x_coord + input_y_coord * NUM_COLUMNS;
                    return {input_x_coord, input_y_coord};
                }
            }
        }
    }
    return {-1, -1};
}

void Interface::place(std::size_t cords, Interface::Player player)
{
    m_board[cords] = player;
}
