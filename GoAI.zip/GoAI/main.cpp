#include "Board.h"
#include "Game.h"
#include "AI.h"
#include "Interface.hpp"
#include "TextField.hpp"
#include "Button.hpp"
#include "Sprite.hpp"
#include "Resources.hpp"

#include <cstdlib>
#include <algorithm>
#include <SFML/Window/Event.hpp>
#include <fstream>


bool tomenu = false;
void menu(){
    tomenu = true;
}

bool is_number(const std::string s){
    if(s.empty()){ return false; }

    return std::find_if(s.begin(), s.end(), [](unsigned char c) { return !std::isdigit(c); }) == s.end(); 
    //i copied this from some random stack overflow thread and this code is impossible to parse holy shit
}

#define MENU_WIDTH 800
#define MENU_HEIGHT 800


enum class State{None, Menu, Bot, Player, Tutorial, Win, Size, Error};


int main(int argc, char **argv) {
    int size = MAX_BOARDSIZE;
    int iter = 2;
    for (int i = 1; i < argc; ++i) {
        if (std::string(argv[i]) == "-size") { 
            if(i + 1 == argc){
                std::cerr << "Error: -size requires an argument" << std::endl;
            }
            else{
                std::string arg = std::string(argv[i+1]);
                if(!is_number(arg)){
                    std::cerr << "Error: argument to -size must be a positive integer " << std::endl;
                }
                size = std::atoi(argv[i+1]); //TODO: add check that size is valid (cant be < 5 or > 19 and must be odd
            }
        }
        else if (std::string(argv[i]) == "-iter") { //iter for minimax
            if(i + 1 == argc){
                std::cerr << "Error: -iter requires an argument" << std::endl;
            }
            else{
                std::string arg = std::string(argv[i+1]);
                if(!is_number(arg)){
                    std::cerr << "Error: argument to -size must be a positive integer " << std::endl;
                }
                iter = std::atoi(argv[i+1]); 
            }
        }

    }
    State mode = State::Menu;
    const unsigned int FPS = 60;
    bool redraw = true;
    std::int32_t width = MENU_WIDTH, height = MENU_HEIGHT;

    sf::RenderWindow window(sf::VideoMode(width, height), "Go");
    window.setFramerateLimit(FPS);

    sf::Clock clock;
    TextField field{"File name "};
    Sprite rules{Resources::resources.rules_texture};

    field.hide();
    rules.hide();

    std::vector<std::pair<std::uint32_t, std::uint32_t>> highlights(0);

    std::function<std::array<Button, 3>&()> get_buttons;

    auto showMenu = [&](){
        for (auto &item : get_buttons())
            item.show();
        mode = State::Menu;
        //window.setSize(sf::Vector2u(MENU_WIDTH, MENU_HEIGHT));
    };

    auto tutorial = ([&](){
        rules.show();
        for (auto &item : get_buttons())
            item.hide();
        mode = State::Tutorial;
    });

    auto play = ([&]{
        mode = State::Bot;
    });

    auto play_2 = ([&]{
        mode = State::Player;
    });

    bool player_move = true;
    std::array<Button, 3> buttons
    { Button
        {"Tutorial", sf::Vector2i{width/2, height/2}, tutorial},
        {"Play with bot", {width/2, height/2+100}, play},
        {"Play", {width/2, height/2+200}, play_2}
    };
    int state_text{0};
    get_buttons = [&buttons]()->std::array<Button, 3>&{ return buttons; };

    Interface anInterface{static_cast<size_t>(size), window};
    Game anGame{static_cast<uint8_t>(size)};
    anGame.setInterface(&anInterface);
    std::vector<std::string> history{};
    sf::Event event{};
    while (window.isOpen()){

        ///Draw stuff if ready
        if (redraw)
        {
            if(mode == State::Player || mode == State::Bot) {
                if (anGame.ongoing()) {
                    if(player_move){
                        auto input = anInterface.get_input();
                        if(input.x!=-1) {
                            auto move = anGame.get_vertex(input.y, input.x);
                            if(anGame.move(move)) {
                                history.push_back(anGame.move_to_text(move));
                                std::cout << input.y << " x " << input.x << std::endl;
                                anGame.print();
                                if (mode == State::Bot)
                                    player_move = false;
                            }else{
                                std::cout << "Whats move " << input.y << " x " << input.x << std::endl;
                            }
                        }
                    }else{
                        auto move = bestMove(anGame, iter);
                        if(!anGame.move(move)){
                            mode = State::Win;
                            anGame.pass();
                            //fuseki(anGame)
                        }
                        history.push_back(anGame.move_to_text(move));
                        anGame.print();
                        player_move = true;
                        anGame.print();
                    }
                }
                anInterface.draw();
            }else {
                redraw = false;
                window.clear(sf::Color::Yellow);
                for (auto &item: Entry::drawable)
                    item->draw(window);
                window.display();
            }
        }

        if (clock.getElapsedTime().asSeconds() >= 1.0f / FPS)
        {
            redraw = true; //We're ready to redraw everything

            clock.restart();
        }

        if(tomenu){
            tomenu = false;
            showMenu();
        }

        //Handle input
        if(mode == State::Menu || mode==State::Tutorial )
        while (window.pollEvent(event))
        {
            switch (event.type) {
                case sf::Event::Closed:
                    window.close();
                    exit(0);
                case sf::Event::TextEntered:
                    for(auto item : Entry::textEntered)
                        item->handle(event, window);
                    break;
                case sf::Event::KeyReleased:
                    if(mode == State::Tutorial) {
                        for (auto &item: get_buttons())
                            item.show();
                        mode = State::Menu;
                        rules.hide();
                    }
                    if(event.key.code == sf::Keyboard::Enter){
                        if(state_text == 0) {
                            field.show();
                            state_text++;
                        }else if(state_text == 1){
                            if(mode == State::Menu) {
                                std::ifstream file;
                                file.open(field.getString());
                                history.clear();
                                std::string input;
                                while (file >> input)
                                    history.push_back(input);
                                for (auto &it: history)
                                    anGame.move(anGame.text_to_move(it));
                                file.close();
                            }else{
                                std::ofstream file;
                                file.open(field.getString());
                                for (auto &it: history)
                                    file << it;
                                file.close();
                            }
                            state_text = 0;
                            field.hide();
                        }
                    }
                    break;
                case sf::Event::MouseButtonReleased:
                    if(mode == State::Tutorial){
                        //tutorial();
                        break;
                    }else{
                        for (auto item : Entry::mouseButtonReleased)
                            item->handle(event, window);
                    }
                    break;
                case sf::Event::MouseMoved:
                    for(auto item : Entry::mouseMoved)
                        item->handle(event, window);
                    break;
            }
        }
    }
    return 0;
}
