#ifndef GOAI_INTERFACE_HPP
#define GOAI_INTERFACE_HPP

#include <SFML/Graphics/RenderWindow.hpp>
#include <SFML/Graphics/RectangleShape.hpp>
#include <SFML/Graphics/RenderTexture.hpp>


struct Board;

struct Interface {
    enum class Player{None, Black, White, Error, Size};

    explicit Interface(std::size_t size, sf::RenderWindow &window);
    explicit Interface(const std::string& nameFile);
    void create_board();
    sf::RenderWindow& get_game_window();
    void draw();
    struct Input{int x,y;};
    Input get_input();
    void place(std::size_t x, std::size_t y, Player player);
    void place(std::size_t cords, Player player);
    void save(const std::string& nameFile);
    Board* board;
    sf::RenderWindow *m_window{nullptr};
private:
    std::vector<Player> m_board;
    sf::RenderTexture m_desk;
    sf::RectangleShape m_board_rect;
    sf::RectangleShape m_screen_rect;
};


#endif //GOAI_INTERFACE_HPP
